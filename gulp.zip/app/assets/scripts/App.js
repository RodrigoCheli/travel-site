var $ = require('jquery');

var Person = require('./modules/Person');

var john = new Person("john Doe", "blue");
john.greet();

var lila = new Person("Lila Lali", "Larange");
lila.greet();

$("h1").remove();
