function Person(fullname, favColor){
  this.name = fullname;
  this.favoriteColor = favColor;
  this.greet = function(){
    console.log("Hello, my name is " + this.name + "and may fav color is " + this.favColor + ".");
  }
}

module.exports = Person;
