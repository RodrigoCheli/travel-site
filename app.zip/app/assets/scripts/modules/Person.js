/*function Person(fullname, favColor){
  this.name = fullname;
  this.favoriteColor = favColor;
  this.greet = function(){
    console.log("Hello, my name is " + this.name + "and may fav color is " + this.favColor + ".");
  }
}

class Person{
  constructor(fullName, favColor){
    this.name = fullName;
    this.favColor = favColor;
  }

  greet(){
    console.log("Hi there, my name is " + this.name + "and may fav color is " + this.favColor + ".");
  }
}

export default Person;
*/
